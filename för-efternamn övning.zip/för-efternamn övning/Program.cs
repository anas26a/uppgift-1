﻿using System;

namespace för_efternamn_övning
{


    class Program
    {
        static void Main(string[] args)
        {
            Info info = new Info();

            Console.Write("Namn: ");
            String namn =  Console.ReadLine();

            Console.Write("Efternamn: ");
            String efternamn = Console.ReadLine();

            Console.Write("Födelsedatum format(dd/mm/yyyy) : ");
            String age1 = Console.ReadLine();


            DateTime fdag = DateTime.ParseExact(age1, "dd/MM/yyyy", null);

            DateTime today = DateTime.Today;
            int age = today.Year - fdag.Year;

            bool over18;
            if (age >= 18)
            {
                over18 = true;
            }
            else
            {
                over18 = false;
            }

            Console.WriteLine("Vikt: ");
            decimal vikt = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Längd: ");
            decimal length = Convert.ToDecimal(Console.ReadLine());


            decimal bmi = Convert.ToDecimal(vikt / (length * length));

            Console.WriteLine("/////////////////////////DINA UPPGIFTER/////////////////////////");

            Console.WriteLine("Du heter: " + namn + " " + efternamn);

            Console.WriteLine("Över 18 ? " + over18);

            Console.WriteLine("Du väger: " + vikt + "kg");

            Console.WriteLine("Du är " + length + " cm lång");

            Console.WriteLine("BMI :" + bmi);

            Console.ReadKey();

        }
    }
}
